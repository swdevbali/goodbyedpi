1. Download dan Extract GoodbyeDPI disini https://github.com/ValdikSS/GoodbyeDPI/releases
2. Taruh semua file yang di folder config ke folder goodbyedpi-0.1.5rc1 yang diextract tadi
3. Jalankan file install_service.cmd sebagai administrator